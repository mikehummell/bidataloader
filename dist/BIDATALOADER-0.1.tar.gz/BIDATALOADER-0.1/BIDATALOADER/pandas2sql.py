def df2load():
    print(test)